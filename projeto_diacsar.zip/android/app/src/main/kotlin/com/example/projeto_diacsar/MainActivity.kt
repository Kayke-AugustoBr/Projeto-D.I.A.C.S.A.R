package com.example.projeto_diacsar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
